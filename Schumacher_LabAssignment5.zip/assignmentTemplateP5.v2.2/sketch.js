let T=0
let u=0
let cX=100
let cY=-10
function setup() {
  createCanvas(400, 400);
  frameRate(240)
}
function mousePressed(){
  if(T<1){T=2}else{T=0}
}

function keyPressed(){
  if(keyCode === ENTER){
  if(u<1){u=2}else{u=0}
  }
}

function draw() {
  background(220);
  circle (cX,cY,10)
  if(T>1){cY+=1
         }
  if(cY>410){cY=-10
            cX=random(0,width)}
  if(u>1){cX++}
}

