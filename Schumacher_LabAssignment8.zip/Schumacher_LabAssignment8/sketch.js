let pumpkinClipArt; //https://www.pngfind.com/pngs/m/693-6932035_transparent-background-halloween-pumpkin-clipart-hd-png-download.png
let dancingSkeleton; //https://cdn.krikey.ai/krikey-ai/img/landing-pages/dancing-skeleton-page/Shy%20Kids%20Circle%20Dance%20B.gif
let x=0
let mX
let mY

function preload(){
pumpkinClipArt = loadImage('/assets/pumpkinClipArt.png')
dancingSkeleton = loadImage('assets/DancingSkeleton.gif')

}

function setup() {
  createCanvas(1680,920);
}

function draw() {
  background('orange');
  textSize(40)
  textFont('Curiour New',60)
  textStyle(BOLD)
  text('Happy Halloween',640,500)
image(pumpkinClipArt, 100,690)
image(pumpkinClipArt,1330,690)
scale(0.5)
if(x>0){
image(dancingSkeleton,mX,mY)
}
}


function mouseClicked(){
if(x<1){x+=2}
else{x-=2}
mX=mouseX
mY=mouseY
}

