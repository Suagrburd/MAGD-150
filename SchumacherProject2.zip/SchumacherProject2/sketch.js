let p1CardNum = [0,0,0,0,0,0,0,0,0]
let p1CardSuit = [4,4,4,4,4,4,4,4,4]
let p2CardNum = [0,0,0,0,0,0,0,0,0]
let p2CardSuit = [4,4,4,4,4,4,4,4,4]
let p1Score = (0);
let p2Score = (0);
const card = [
['s2','s3','s4','s5','s6','s7','s8','s9','s10','sJ','sQ','sK','sA'],
['d2','d3','d4','d5','d6','d7','d8','d9','d10','dJ','dQ','dK','dA'],
['c2','c3','c4','c5','c6','c7','c8','c9','c10','cJ','cQ','cK','cA'],
['h2','h3','h4','h5','h6','h7','h8','h9','h10','hJ','hQ','hK','hA']
]
const cardScore = [2,3,4,5,6,7,8,9,10,11,12,13,1]
let discard = []
let cardNum = (0);
let suit = (4);
let p1B=(0)
let p2B=(0)
let l=(0)
let w=(0)
let d=(0)
let r=(0)
let scoreDif
let start=(0)
//2 3 4 5 6 7 8 9 10 J Q  K  A
//0 1 2 3 4 5 6 7 8  9 10 11 12

//spade diamond clover heart transparent
//0     1       2      3     4
let score = (0);
let Sp2;
let rulesImg;

function preload(){
 // Sp2 = loadImage('assets/spades/Sp2.png')
 cardImg = [
[loadImage ('assets/spades/Sp2.png'),loadImage ('assets/spades/Sp3.png'),loadImage ('assets/spades/Sp4.png'),loadImage ('assets/spades/Sp5.png'),loadImage ('assets/spades/Sp6.png'),loadImage ('assets/spades/Sp7.png'),loadImage ('assets/spades/Sp8.png'),loadImage ('assets/spades/Sp9.png'),loadImage ('assets/spades/Sp10.png'),loadImage ('assets/spades/SpJ.png'),loadImage ('assets/spades/SpQ.png'),loadImage ('assets/spades/SpK.png'),loadImage ('assets/spades/SpA.png')],
[loadImage ('assets/diamonds/D2.png'),loadImage ('assets/diamonds/D3.png'),loadImage ('assets/diamonds/D4.png'),loadImage ('assets/diamonds/D5.png'),loadImage ('assets/diamonds/D6.png'),loadImage ('assets/diamonds/D7.png'),loadImage ('assets/diamonds/D8.png'),loadImage ('assets/diamonds/D9.png'),loadImage ('assets/diamonds/D10.png'),loadImage ('assets/diamonds/J10.png'),loadImage ('assets/diamonds/Q10.png'),loadImage ('assets/diamonds/K10.png'),loadImage('assets/diamonds/DA.png')],
[loadImage ('assets/clubs/C2.png'),loadImage ('assets/clubs/C3.png'),loadImage ('assets/clubs/C4.png'),loadImage ('assets/clubs/C5.png'),loadImage ('assets/clubs/C6.png'),loadImage ('assets/clubs/C7.png'),loadImage ('assets/clubs/C8.png'),loadImage ('assets/clubs/C9.png'),loadImage ('assets/clubs/C10.png'),loadImage ('assets/clubs/CJ.png'),loadImage ('assets/clubs/CQ.png'),loadImage ('assets/clubs/CK.png'),loadImage ('assets/clubs/CA.png')],
[loadImage ('assets/hearts/H2.png'),loadImage ('assets/hearts/H3.png'),loadImage ('assets/hearts/H4.png'),loadImage ('assets/hearts/H5.png'),loadImage ('assets/hearts/H6.png'),loadImage ('assets/hearts/H7.png'),loadImage ('assets/hearts/H8.png'),loadImage ('assets/hearts/H9.png'),loadImage ('assets/hearts/H10.png'),loadImage ('assets/hearts/HJ.png'),loadImage ('assets/hearts/HQ.png'),loadImage ('assets/hearts/HK.png'),loadImage ('assets/hearts/HA.png')],
[loadImage ('assets/spades/0.png')]
 ]
 rulesImg = loadImage('assets/Rules.png')
}
//https://opengameart.org/content/card-deck-fronts

function setup() {
  createCanvas(1690, 900);
  }

function draw(){
  fill('darkgreen')
  rect(-10,-10,2500,1000)
  scale(.2)
  //Player
  image(cardImg[p1CardSuit[0]][p1CardNum[0]],350,300)
  image(cardImg[p1CardSuit[1]][p1CardNum[1]],1350,300)
  image(cardImg[p1CardSuit[2]][p1CardNum[2]],2350,300)
  image(cardImg[p1CardSuit[3]][p1CardNum[3]],3350,300)
  image(cardImg[p1CardSuit[4]][p1CardNum[4]],4350,300)
  image(cardImg[p1CardSuit[5]][p1CardNum[5]],5350,300)
  image(cardImg[p1CardSuit[6]][p1CardNum[6]],6350,300)
  image(cardImg[p1CardSuit[7]][p1CardNum[7]],7350,300)
  image(cardImg[p1CardSuit[8]][p1CardNum[8]],8500,300)
  //Dealer
  image(cardImg[p2CardSuit[0]][p2CardNum[0]],350,3000)
  image(cardImg[p2CardSuit[1]][p2CardNum[1]],1350,3000)
  image(cardImg[p2CardSuit[2]][p2CardNum[2]],2350,3000)
  image(cardImg[p2CardSuit[3]][p2CardNum[3]],3350,3000)
  image(cardImg[p2CardSuit[4]][p2CardNum[4]],4350,3000)
  image(cardImg[p2CardSuit[5]][p2CardNum[5]],5350,3000)
  image(cardImg[p2CardSuit[6]][p2CardNum[6]],6350,3000)
  image(cardImg[p2CardSuit[7]][p2CardNum[7]],7350,3000)
  image(cardImg[p2CardSuit[8]][p2CardNum[8]],8500,3000)
  scale(1)
  fill('black')
  textSize(100)
  //text('Press "1" to Start',1400,100)
  //text('Press "H" to Hit',3800,100)
  //text('Press "S" to Stand',6300,100)
  text('Press "R" to read rules',4000,4400)
  textSize(250)
  text('Player:'+p1Score,800,1900)
  text('Dealer:'+p2Score,800,2800)
  text('Score:'+score,7000,2400)
  if (d>1){
      textSize(500)
      text('DRAW',3700,2000)
    }
  if(p1Score>21){
    fill('black')
    textSize(500)
    text('BUST',3700,2900)
    if(scoreDif<0){
    text(scoreDif,3700,2000)}
  }
  
  if (w>1){
    textSize(500)
    text('WIN!',3700,2000)
    text('+'+scoreDif,3700,2900)
  }
  if (l>1){
    textSize(500)
    text('LOSE!',3700,2900)
    text(scoreDif,3700,2000)
  }
  if (r>1){
    fill('white')
    rect(2500,1000,3500,2000)
    fill('black')
    textSize(100)
    text('This is game is called Ventti!',2600,1200)
    text('Ventti is another version of blackjack',2600,1400)
    text('having the same objective, have your ',2600,1500)
    text('card total to 21 without going over,',2600,1600)
    text('and beat the dealer. The Only ',2600,1700)
    text('difference is the card values.',2600,1800)
    text('Look to the right for each card values!',2600,2000)
    text('Press "1" to Start Round',2600,2400)
    text('Press "S" to Stand',2600,2600)
    text('Press "H" to Hit',2600,2800)
    textSize(50)
    text('Press "R" again to close',3500,2900)
    scale(1.7)
    image(rulesImg,2600,600)
    
  }
}
function keyPressed() { 
  if(key === '1'){//------------------------------------------------------------------------------------------------------------------------------------start
    if(start<1){
    start=2
    p1CardNum = [0,0,0,0,0,0,0,0,0]
    p1CardSuit = [4,4,4,4,4,4,4,4,4]
    p2CardNum = [0,0,0,0,0,0,0,0,0]
    p2CardSuit = [4,4,4,4,4,4,4,4,4]
    p1Score=(0)
    p2Score=(0)
   suit = Math.floor(random(0,4))
   cardNum = Math.floor(random(0,13))
   p1CardNum.unshift(cardNum)
   p1CardSuit.unshift(suit)
   p1Score = (p1Score + cardScore[cardNum])

   suit = Math.floor(random(0,4))
   cardNum = Math.floor(random(0,13))
   p2CardNum.unshift(cardNum)
   p2CardSuit.unshift(suit)
   p2Score = (p2Score + cardScore[cardNum])
   w=0
   l=0
   d=0
   scoreDif=(0)
  }
}
  if(start>1){
  //HIT
  if (key === 'h'){//-------------------------------------------------------------------------------------------------------------------------------------hit
   suit = Math.floor(random(0,4))
   cardNum = Math.floor(random(0,13))
   if (discard.includes(card[suit][cardNum])){
    console.log('Potato')
   }
   if(p1Score<21){
   console.log(suit,cardNum,card[suit][cardNum],cardScore[cardNum])
   p1CardNum.unshift(cardNum)
   p1CardSuit.unshift(suit)
   console.log(p1CardNum)
   console.log(p1CardSuit)
   discard.push(card[suit][cardNum])
   p1Score = (p1Score + cardScore[cardNum])
   console.log(p1Score)
  if (p1Score>21){//----------------------------------------------------------------------------------------------------player bust
    p1B=2
   }}
  else{
 }
 console.log(b)
  }}

  if (key === 's'){ //---------------------------------------------------------------------------------------------------------------------------------STAND
    while(p2Score<16){
   suit = Math.floor(random(0,4))
   cardNum = Math.floor(random(0,13))
   p2CardNum.unshift(cardNum)
   p2CardSuit.unshift(suit)
   p2Score = (p2Score + cardScore[cardNum])

}
     if(p2Score>21){//--------------------------------------------------------------------------------------------------------------dealer busts
      p2B=2
      if(p1Score<22){//-----------------------------------------------------------------------------------dealer bust / player wins
        if((p1Score-p2Score)<0){//------------------------------------------------------------player wins nothing
         scoreDif=(p1Score-(p2Score-cardScore[p2CardNum[0]]))
         if((scoreDif)<0){
          scoreDif=(p1score-(p2score-cardScore[p2CardNum[1]]))
         }
         score=(score+scoreDif)
          w=2}
        if((p1Score-p2Score)>0){ scoreDif=(p1Score-p2Score)
          score=(score+scoreDif)
          w=2
          
        }//-----------------------------------------------player wins thier score - last dealer score that is <21
  }
      if(p1Score>21){d=2
        p1B=2
      }//-------------------------------------------------------------------------dealer bust/player bust = draw
  }
  if(p2Score<22){//---------------------------------------------------------------------------------------------------------dealer doesn't bust
if(p1Score>p2Score){//--------------------------------------------------------------------------player wins
if(p1Score>21){//---------------------------------player busts
  scoreDif=(p2Score-p1Score)
  p1B=2
}
else{
  scoreDif=(p1Score-p2Score)
  w=2}
score=(score+scoreDif)
}
if(p1Score<p2Score){//-------------------------------------------------------------------------player loses
scoreDif=(p1Score-p2Score)
score=(score+scoreDif)
l=2
}
if(p1Score===p2Score){//--------------------------------------------------------------------------------draw
d=2
}
  }
  
start=0
}
if(key === 'r'){
  if (r>1){r=0}
  else{r=2}
}
}
