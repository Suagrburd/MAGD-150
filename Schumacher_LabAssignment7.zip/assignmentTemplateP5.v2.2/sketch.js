let randomNum1=[]
let randomNum2=[]
let values=[]

function setup() {
  createCanvas(400, 400);
  for(let n=0;n<10;n++){
    randomNum1.push(random(0,100))
    randomNum2.push(random(0,100))
    values.push(randomNum1[1]+randomNum2[1])
  }
console.log(randomNum1)
console.log(randomNum2)
console.log(values)
  text(values[1],200,200)
}

